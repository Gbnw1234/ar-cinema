package com.arcinema.app;

import android.content.Context;
import android.graphics.Color;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Cinema {
    public static WebView create(Context c) {
        WebView w = new WebView(c);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        w.setBackgroundColor(Color.BLACK);
        w.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String u) {
                v.evaluateJavascript("RC.init(" + Hub.json() + "," + Hub.urlsJson() + ")", null);
            }
        });
        w.loadUrl("http://127.0.0.1:" + Hub.server.port() + "/cinema.html");
        return w;
    }
}
