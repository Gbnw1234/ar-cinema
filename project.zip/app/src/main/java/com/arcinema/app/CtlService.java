package com.arcinema.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

/** ใช้ส่งการแตะ/ลากไปที่หน้าจอมือถือเท่านั้น ไม่อ่านเนื้อหาบนหน้าจอ */
public class CtlService extends AccessibilityService {
    public static volatile CtlService inst;

    @Override protected void onServiceConnected() { inst = this; Hub.msg = "เปิดบริการควบคุมแล้ว"; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }
    @Override public boolean onUnbind(Intent i) { inst = null; return super.onUnbind(i); }

    public void gesture(float x1, float y1, float x2, float y2, long ms) {
        Path p = new Path();
        p.moveTo(x1, y1);
        if (Math.abs(x1 - x2) > 1 || Math.abs(y1 - y2) > 1) p.lineTo(x2, y2);
        GestureDescription g = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p, 0, Math.max(ms, 1))).build();
        dispatchGesture(g, null, null);
    }
}
