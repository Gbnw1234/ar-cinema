package com.arcinema.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Presentation;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.display.DisplayManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Display;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;
import java.util.function.Consumer;

public class MainActivity extends Activity implements SensorEventListener {
    final Handler h = new Handler(Looper.getMainLooper());
    FrameLayout holder, tabBody;
    TextView status, timeTv;
    SeekBar seekBar;
    WebView cinema;
    Presentation pres;
    DisplayManager dm;
    SensorManager sm;
    Sensor gyro, grav;
    final float[] g = new float[]{0, 0, 9.8f};
    long lastT, lastSend;
    boolean seeking, dim;
    String extName = "";

    final DisplayManager.DisplayListener dl = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int id) { h.postDelayed(MainActivity.this::startCinema, 800); }
        @Override public void onDisplayRemoved(int id) { h.postDelayed(MainActivity.this::startCinema, 300); }
        @Override public void onDisplayChanged(int id) { }
    };

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    String f(float v) { return String.format(Locale.US, "%.4f", v); }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    void js(String s) { if (cinema != null) cinema.evaluateJavascript(s, null); }
    void push() { js("RC.set(" + Hub.json() + ")"); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Hub.cr = getContentResolver();
        Hub.load(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        try {
            if (Hub.server == null) { WebServer ws = new WebServer(getAssets()); ws.start(); Hub.server = ws; }
        } catch (Exception e) { toast("เปิดเซิร์ฟเวอร์ในเครื่องไม่ได้: " + e); }
        dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        grav = sm.getDefaultSensor(Sensor.TYPE_GRAVITY);
        if (grav == null) grav = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        buildUi();
        dm.registerDisplayListener(dl, h);
        startCinema();
        poll();
    }

    // ---------------- โรงหนัง (บนแว่นหรือพรีวิวบนมือถือ) ----------------
    Display findExt() {
        for (Display d : dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION))
            if (d.getDisplayId() != Display.DEFAULT_DISPLAY) return d;
        for (Display d : dm.getDisplays())
            if (d.getDisplayId() != Display.DEFAULT_DISPLAY && (d.getFlags() & Display.FLAG_PRIVATE) == 0) return d;
        return null;
    }

    void stopCinema() {
        try { if (pres != null) pres.dismiss(); } catch (Exception e) { }
        pres = null;
        holder.removeAllViews();
        if (cinema != null) { try { cinema.destroy(); } catch (Exception e) { } cinema = null; }
    }

    void startCinema() {
        if (Hub.server == null) return;
        stopCinema();
        Display ext = findExt();
        if (ext != null) {
            try {
                pres = new Presentation(this, ext) {
                    @Override protected void onCreate(Bundle b) {
                        super.onCreate(b);
                        cinema = Cinema.create(getContext());
                        setContentView(cinema);
                    }
                };
                pres.show();
                extName = ext.getName();
                status.setText("✅ ฉายขึ้นจอแว่นแล้ว (" + extName + ") — มือถือเป็นรีโมท");
                TextView t = new TextView(this);
                t.setText("กำลังฉายบนแว่น\nใช้แท็บ 'รีโมท' ด้านล่าง");
                t.setTextColor(0xFF88AA88); t.setGravity(android.view.Gravity.CENTER);
                holder.addView(t, new FrameLayout.LayoutParams(-1, -1));
                return;
            } catch (Exception e) {
                pres = null; cinema = null;
                status.setText("⚠ ฉายขึ้นแว่นไม่ได้: " + e.getMessage() + " → แสดงตัวอย่างบนมือถือแทน");
            }
        } else {
            status.setText("⚠ ไม่พบจอแว่น (ปิด DeX และตั้ง HDMI mode เป็น Screen mirroring แล้วต่อแว่นใหม่) — แสดงตัวอย่างบนมือถือ");
        }
        cinema = Cinema.create(this);
        holder.addView(cinema, new FrameLayout.LayoutParams(-1, -1));
    }

    void poll() {
        if (cinema != null) {
            cinema.evaluateJavascript("RC.state()", v -> {
                try {
                    if (v == null) return;
                    String[] p = v.replace("\"", "").split("\\|");
                    if (p.length < 7) return;
                    float t = Float.parseFloat(p[0]), dur = Float.parseFloat(p[1]);
                    Hub.x = Float.parseFloat(p[4]); Hub.y = Float.parseFloat(p[5]); Hub.w = Float.parseFloat(p[6]);
                    if (timeTv != null) timeTv.setText(fmt(t) + " / " + fmt(dur) + (p[2].equals("1") ? "   ▶" : "   ⏸"));
                    if (seekBar != null && !seeking && dur > 0) seekBar.setProgress((int) (t / dur * 1000));
                } catch (Exception e) { }
            });
        }
        h.postDelayed(this::poll, 500);
    }

    String fmt(float s) { int t = (int) s; return (t / 60) + ":" + String.format(Locale.US, "%02d", t % 60); }

    // ---------------- UI ----------------
    TextView tv(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(0xFFCCCCDD);
        t.setPadding(dp(4), dp(6), dp(4), dp(2));
        return t;
    }

    Button btn(String t, Runnable r) {
        Button x = new Button(this);
        x.setText(t); x.setAllCaps(false); x.setTextSize(13); x.setMinWidth(0); x.setMinimumWidth(0);
        x.setPadding(dp(4), 0, dp(4), 0);
        x.setOnClickListener(v -> r.run());
        return x;
    }

    Button rep(String t, Runnable r) {
        Button x = btn(t, () -> { });
        x.setOnClickListener(null);
        x.setOnTouchListener(new View.OnTouchListener() {
            final Runnable loop = new Runnable() { @Override public void run() { r.run(); h.postDelayed(this, 60); } };
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: v.setPressed(true); h.post(loop); return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: v.setPressed(false); h.removeCallbacks(loop); Hub.save(MainActivity.this); return true;
                }
                return false;
            }
        });
        return x;
    }

    LinearLayout hrow(View... vs) {
        LinearLayout l = new LinearLayout(this);
        for (View v : vs) l.addView(v, new LinearLayout.LayoutParams(0, dp(48), 1));
        return l;
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    void sliderRow(LinearLayout parent, String label, float mn, float mx, float cur, Consumer<Float> c) {
        parent.addView(tv(label, 13));
        SeekBar s = new SeekBar(this);
        s.setMax(1000);
        s.setProgress((int) ((cur - mn) / (mx - mn) * 1000));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) { if (u) { c.accept(mn + (mx - mn) * p / 1000f); push(); } }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { Hub.save(MainActivity.this); }
        });
        parent.addView(s);
    }

    void buildUi() {
        LinearLayout root = vbox();
        root.setBackgroundColor(0xFF101016);
        root.setPadding(dp(8), dp(28), dp(8), dp(8));
        holder = new FrameLayout(this);
        holder.setBackgroundColor(Color.BLACK);
        root.addView(holder, new LinearLayout.LayoutParams(-1, dp(150)));
        status = tv("", 12);
        root.addView(status);
        root.addView(hrow(btn("📂 เลือกวิดีโอ", this::pickVideo), btn("🔗 ลิงก์", this::askLink), btn("📺 ฉายขึ้นแว่น", this::startCinema)));
        root.addView(hrow(btn("รีโมท", () -> showTab(0)), btn("ปรับจอ", () -> showTab(1)), btn("ตั้งค่า", () -> showTab(2))));
        tabBody = new FrameLayout(this);
        root.addView(tabBody, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        showTab(0);
    }

    void showTab(int i) {
        tabBody.removeAllViews();
        View v = i == 0 ? remoteTab() : i == 1 ? screenTab() : settingsTab();
        tabBody.addView(v, new FrameLayout.LayoutParams(-1, -1));
    }

    View remoteTab() {
        LinearLayout l = vbox();
        Pad pad = new Pad();
        l.addView(pad, new LinearLayout.LayoutParams(-1, 0, 1));
        l.addView(hrow(btn("⏪ 10", () -> js("RC.seek(-10)")), btn("⏯", () -> js("RC.toggle()")),
            btn("10 ⏩", () -> js("RC.seek(10)")), btn("⌖ จูนเมาส์", this::recenter)));
        timeTv = tv("0:00 / 0:00", 13);
        l.addView(timeTv);
        seekBar = new SeekBar(this);
        seekBar.setMax(1000);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) { }
            @Override public void onStartTrackingTouch(SeekBar sb) { seeking = true; }
            @Override public void onStopTrackingTouch(SeekBar sb) { seeking = false; js("RC.seekTo(" + f(sb.getProgress() / 1000f) + ")"); }
        });
        l.addView(seekBar);
        l.addView(tv("เสียง", 12));
        SeekBar vb = new SeekBar(this);
        vb.setMax(100); vb.setProgress(100);
        vb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) { if (u) js("RC.vol(" + f(p / 100f) + ")"); }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        l.addView(vb);
        return l;
    }

    View screenTab() {
        ScrollView sv = new ScrollView(this);
        LinearLayout l = vbox();
        sv.addView(l);
        sliderRow(l, "ขนาดจอ", 0.5f, 10f, Hub.w, v -> Hub.w = v);
        sliderRow(l, "ระยะห่าง", 1.5f, 12f, Hub.d, v -> Hub.d = v);
        sliderRow(l, "ความโค้ง", 0f, 1.2f, Hub.k, v -> Hub.k = v);
        sliderRow(l, "ช่องว่างระหว่างจอ", 0f, 1f, Hub.gap, v -> Hub.gap = v);
        sliderRow(l, "ความสว่าง", 0.3f, 1.5f, Hub.b, v -> Hub.b = v);
        l.addView(tv("ย้ายจอ (กดค้างได้)", 13));
        l.addView(hrow(new View(this), rep("⬆", () -> { Hub.y += .05f; push(); }), new View(this)));
        l.addView(hrow(rep("⬅", () -> { Hub.x -= .08f; push(); }), btn("⌂ กลับจุดกลาง", () -> { Hub.x = Hub.hx; Hub.y = Hub.hy; push(); }), rep("➡", () -> { Hub.x += .08f; push(); })));
        l.addView(hrow(new View(this), rep("⬇", () -> { Hub.y -= .05f; push(); }), new View(this)));
        l.addView(hrow(btn("⌖ ตั้งจุดนี้เป็นกลางจอ", () -> { Hub.hx = Hub.x; Hub.hy = Hub.y; Hub.save(this); toast("บันทึกจุดกลางแล้ว"); })));
        l.addView(tv("จำนวนจอ", 13));
        l.addView(hrow(btn("1 จอ", () -> setN(1)), btn("2 จอ", () -> setN(2)), btn("3 จอ", () -> setN(3))));
        l.addView(hrow(btn("ภาพต่อเนื่อง / แยกแต่ละจอ", () -> { Hub.span = !Hub.span; push(); Hub.save(this); toast(Hub.span ? "ภาพต่อเนื่องกัน" : "แต่ละจอแสดงวิดีโอของตัวเอง"); })));
        return sv;
    }

    void setN(int n) { Hub.n = n; push(); Hub.save(this); }

    View settingsTab() {
        ScrollView sv = new ScrollView(this);
        LinearLayout l = vbox();
        sv.addView(l);
        Button mode = btn(Hub.air ? "โหมดเมาส์: เมาส์อากาศ (ไจโร)" : "โหมดเมาส์: ทัชแพด", () -> { });
        mode.setOnClickListener(v -> {
            Hub.air = !Hub.air;
            mode.setText(Hub.air ? "โหมดเมาส์: เมาส์อากาศ (ไจโร)" : "โหมดเมาส์: ทัชแพด");
            regSensors();
            Hub.save(this);
        });
        l.addView(hrow(mode));
        sliderRow(l, "ความไวเมาส์อากาศ", 0.3f, 4f, Hub.sens, v -> Hub.sens = v);
        sliderRow(l, "ความไวทัชแพด", 0.5f, 4f, Hub.padSens, v -> Hub.padSens = v);
        Button ix = btn("กลับทิศซ้าย-ขวา: " + (Hub.invX ? "เปิด" : "ปิด"), () -> { });
        ix.setOnClickListener(v -> { Hub.invX = !Hub.invX; ix.setText("กลับทิศซ้าย-ขวา: " + (Hub.invX ? "เปิด" : "ปิด")); Hub.save(this); });
        Button iy = btn("กลับทิศบน-ล่าง: " + (Hub.invY ? "เปิด" : "ปิด"), () -> { });
        iy.setOnClickListener(v -> { Hub.invY = !Hub.invY; iy.setText("กลับทิศบน-ล่าง: " + (Hub.invY ? "เปิด" : "ปิด")); Hub.save(this); });
        l.addView(hrow(ix, iy));
        l.addView(hrow(btn("⌖ จูนเมาส์ให้อยู่กลางจอ", this::recenter)));
        l.addView(hrow(btn("🔆 หรี่/คืนความสว่างจอมือถือ", this::toggleDim)));
        l.addView(tv("วิธีใช้: ปิด DeX → ตั้งค่า > การเชื่อมต่อ > การตั้งค่าการเชื่อมต่อเพิ่มเติม > HDMI mode = Screen mirroring → ต่อแว่น → กด 'ฉายขึ้นแว่น'. ใช้ทัชแพดหรือเมาส์อากาศขยับเลเซอร์ แตะ = คลิก (คลิกที่จอ = เล่น/หยุด), 2 นิ้วลาก = ย้ายจอ, หนีบ = ขยาย/ย่อ", 12));
        return sv;
    }

    void recenter() { Hub.px = .5f; Hub.py = .5f; js("RC.ptr(0.5,0.5)"); }

    void toggleDim() {
        dim = !dim;
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = dim ? 0.01f : WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
        getWindow().setAttributes(lp);
    }

    // ---------------- เลือกวิดีโอ / ลิงก์ ----------------
    void pickVideo() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, 1);
    }

    void askLink() {
        final EditText et = new EditText(this);
        et.setHint("https://.../video.mp4");
        new AlertDialog.Builder(this).setTitle("เปิดลิงก์วิดีโอ (mp4 / m3u8)").setView(et)
            .setPositiveButton("เปิด", (d, w) -> {
                String u = et.getText().toString().trim();
                if (u.isEmpty()) return;
                synchronized (Hub.class) { Hub.uri.clear(); Hub.src.clear(); Hub.uri.add(null); Hub.src.add(u); }
                Hub.n = 1; Hub.span = true;
                js("RC.set(" + Hub.json() + ");RC.load(" + Hub.urlsJson() + ")");
            }).setNegativeButton("ยกเลิก", null).show();
    }

    @Override protected void onActivityResult(int rq, int rc, Intent d) {
        super.onActivityResult(rq, rc, d);
        if (rq != 1 || rc != RESULT_OK || d == null) return;
        synchronized (Hub.class) {
            Hub.uri.clear(); Hub.src.clear();
            int n = d.getClipData() != null ? d.getClipData().getItemCount() : 1;
            for (int i = 0; i < n && i < 3; i++) {
                Uri u = d.getClipData() != null ? d.getClipData().getItemAt(i).getUri() : d.getData();
                if (u == null) continue;
                try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception e) { }
                Hub.uri.add(u);
                Hub.src.add("/v/" + (Hub.uri.size() - 1) + "?" + System.currentTimeMillis());
            }
        }
        int c = Hub.src.size();
        if (c > 1) { Hub.n = c; Hub.span = false; } else Hub.span = true;
        js("RC.set(" + Hub.json() + ");RC.load(" + Hub.urlsJson() + ")");
        toast("เลือก " + c + " ไฟล์");
    }

    // ---------------- เมาส์ / เซ็นเซอร์ ----------------
    void movePtr(float dx, float dy) {
        Hub.px = Math.max(0f, Math.min(1f, Hub.px + dx));
        Hub.py = Math.max(0f, Math.min(1f, Hub.py + dy));
        long n = SystemClock.uptimeMillis();
        if (n - lastSend >= 12) { lastSend = n; js("RC.ptr(" + f(Hub.px) + "," + f(Hub.py) + ")"); }
    }

    void regSensors() {
        sm.unregisterListener(this);
        lastT = 0;
        if (!Hub.air) return;
        if (gyro != null) sm.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
        if (grav != null) sm.registerListener(this, grav, SensorManager.SENSOR_DELAY_GAME);
        if (gyro == null) toast("เครื่องไม่มีไจโรสโคป ใช้โหมดทัชแพดแทน");
    }

    @Override public void onSensorChanged(SensorEvent e) {
        int t = e.sensor.getType();
        if (t == Sensor.TYPE_GRAVITY) { System.arraycopy(e.values, 0, g, 0, 3); return; }
        if (t == Sensor.TYPE_ACCELEROMETER) { for (int i = 0; i < 3; i++) g[i] = 0.9f * g[i] + 0.1f * e.values[i]; return; }
        if (t == Sensor.TYPE_GYROSCOPE && Hub.air) {
            long now = e.timestamp;
            if (lastT == 0) { lastT = now; return; }
            float dt = (now - lastT) * 1e-9f;
            lastT = now;
            float gn = (float) Math.sqrt(g[0] * g[0] + g[1] * g[1] + g[2] * g[2]);
            if (gn < 1f) return;
            float up = (e.values[0] * g[0] + e.values[1] * g[1] + e.values[2] * g[2]) / gn;
            float k = 1.25f * Hub.sens;
            movePtr(-up * dt * k * (Hub.invX ? -1 : 1), -e.values[0] * dt * k * (Hub.invY ? -1 : 1));
        }
    }

    @Override public void onAccuracyChanged(Sensor s, int a) { }

    @Override protected void onResume() { super.onResume(); regSensors(); }
    @Override protected void onPause() { sm.unregisterListener(this); Hub.save(this); super.onPause(); }

    // ---------------- ทัชแพด ----------------
    class Pad extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final ScaleGestureDetector sg;
        float lx, ly, tot;
        long down;
        boolean multi, reset;

        Pad() {
            super(MainActivity.this);
            setBackgroundColor(0xFF1C1C28);
            sg = new ScaleGestureDetector(MainActivity.this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector d) { js("RC.zoom(" + f(d.getScaleFactor()) + ")"); return true; }
            });
        }

        @Override protected void onDraw(Canvas c) {
            p.setColor(0xFF8888AA); p.setTextSize(dp(14)); p.setTextAlign(Paint.Align.CENTER);
            c.drawText(Hub.air ? "เมาส์อากาศ: ขยับมือถือ • แตะ = คลิก" : "ทัชแพด: ลาก = ขยับเลเซอร์ • แตะ = คลิก", getWidth() / 2f, getHeight() / 2f - dp(8), p);
            c.drawText("2 นิ้วลาก = ย้ายจอ • หนีบ = ขยาย/ย่อ", getWidth() / 2f, getHeight() / 2f + dp(16), p);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            sg.onTouchEvent(e);
            int n = e.getPointerCount();
            float x = 0, y = 0;
            for (int i = 0; i < n; i++) { x += e.getX(i); y += e.getY(i); }
            x /= n; y /= n;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: down = SystemClock.uptimeMillis(); tot = 0; multi = false; reset = false; lx = x; ly = y; break;
                case MotionEvent.ACTION_POINTER_DOWN: multi = true; reset = true; break;
                case MotionEvent.ACTION_POINTER_UP: reset = true; break;
                case MotionEvent.ACTION_MOVE: {
                    if (reset) { lx = x; ly = y; reset = false; break; }
                    float dx = x - lx, dy = y - ly;
                    lx = x; ly = y;
                    tot += Math.hypot(dx, dy);
                    float fw = Math.max(1, getWidth()), fh = Math.max(1, getHeight());
                    if (n == 1) {
                        if (!Hub.air) movePtr(dx / fw * Hub.padSens, dy / fh * Hub.padSens);
                    } else if (!sg.isInProgress()) {
                        js("RC.drag(" + f(dx / fw) + "," + f(dy / fh) + ")");
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                    if (!multi && tot < dp(12) && SystemClock.uptimeMillis() - down < 350) js("RC.click()");
                    break;
            }
            return true;
        }
    }
}
