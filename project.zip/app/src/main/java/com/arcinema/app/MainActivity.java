package com.arcinema.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.function.Consumer;

public class MainActivity extends Activity {
    final Handler h = new Handler(Looper.getMainLooper());
    LinearLayout root;
    TextView status;
    Button lockBtn, spanBtn;
    static final float STEP = 0.04f;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Hub.load(this);
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(36), dp(16), dp(24));
        sv.addView(root);
        setContentView(sv);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);

        TextView t = label("AR Mirror — สตรีมจอมือถือเข้าแว่น");
        t.setTextSize(20);
        status = label("");
        row(btn("▶ เริ่มสตรีมจอ", this::start), btn("■ หยุด", () -> startService(new Intent(this, MirrorService.class).setAction("stop"))));

        label("ย้ายจอ (กดค้างได้)");
        row(new View(this), rep("⬆", () -> mv(0, STEP)), new View(this));
        row(rep("⬅", () -> mv(-STEP, 0)), btn("⌂ กลับจุดกลาง", () -> { Hub.x = Hub.hx; Hub.y = Hub.hy; Hub.dirty = true; }), rep("➡", () -> mv(STEP, 0)));
        row(new View(this), rep("⬇", () -> mv(0, -STEP)), new View(this));
        row(btn("⌖ ตั้งจุดนี้เป็นกลาง", () -> { Hub.hx = Hub.x; Hub.hy = Hub.y; Hub.save(this); toast("บันทึกจุดกลางแล้ว"); }));

        label("ขนาดจอ (กดค้างได้)");
        row(rep("－ เล็กลง", () -> sz(-STEP)), rep("＋ ใหญ่ขึ้น", () -> sz(STEP)));
        seek("ระยะห่างจอ", 1.5f, 12f, Hub.d, v -> { if (!Hub.lock) Hub.d = v; });
        seek("ความโค้ง", 0f, 1.2f, Hub.k, v -> { if (!Hub.lock) Hub.k = v; });
        seek("ความสว่าง", 0.3f, 1.5f, Hub.b, v -> Hub.b = v);

        label("แนวภาพ / จำนวนจอ");
        row(btn("⟳ หมุนภาพ 90°", () -> { if (!Hub.lock) { Hub.rot = (Hub.rot + 1) % 4; Hub.dirty = true; } }));
        row(btn("1 จอ", () -> setN(1)), btn("2 จอ", () -> setN(2)), btn("3 จอ", () -> setN(3)));
        spanBtn = btn("", () -> { Hub.span = !Hub.span; Hub.dirty = true; upd(); });
        row(spanBtn);
        lockBtn = btn("", () -> { Hub.lock = !Hub.lock; upd(); });
        row(lockBtn);
        label("วิธีใช้: กดเริ่ม → เลือก 'ทั้งหน้าจอ' → เปิดแอพอะไรก็ได้ (YouTube, Facebook ฯลฯ) ภาพจะขึ้นบนจอเสมือนในแว่น");
        upd();
        tick();
    }

    void tick() {
        status.setText(Hub.running ? "● กำลังสตรีมไปที่แว่น" : "○ ยังไม่ได้สตรีม");
        h.postDelayed(this::tick, 1000);
    }

    void upd() {
        lockBtn.setText(Hub.lock ? "🔒 ล็อกจอแล้ว (แตะเพื่อปลดล็อก)" : "🔓 จอปรับได้ (แตะเพื่อล็อกตำแหน่ง)");
        spanBtn.setText(Hub.span ? "หลายจอ: ภาพต่อเนื่องกัน" : "หลายจอ: แต่ละจอแสดงภาพเต็ม");
    }

    void mv(float dx, float dy) { if (Hub.lock) return; Hub.x += dx; Hub.y += dy; Hub.dirty = true; }
    void sz(float d) { if (Hub.lock) return; Hub.w = Math.max(0.5f, Math.min(6f, Hub.w + d)); Hub.dirty = true; }
    void setN(int n) { Hub.n = n; Hub.dirty = true; }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setPadding(0, dp(12), 0, dp(4));
        root.addView(t);
        return t;
    }

    Button btn(String t, Runnable r) {
        Button x = new Button(this);
        x.setText(t);
        x.setAllCaps(false);
        x.setOnClickListener(v -> r.run());
        return x;
    }

    Button rep(String t, Runnable r) {
        Button x = new Button(this);
        x.setText(t);
        x.setAllCaps(false);
        x.setOnTouchListener(new View.OnTouchListener() {
            final Runnable loop = new Runnable() {
                @Override public void run() { r.run(); h.postDelayed(this, 60); }
            };
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: v.setPressed(true); h.post(loop); return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: v.setPressed(false); h.removeCallbacks(loop); return true;
                }
                return false;
            }
        });
        return x;
    }

    void row(View... vs) {
        LinearLayout l = new LinearLayout(this);
        for (View v : vs) l.addView(v, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        root.addView(l);
    }

    void seek(String t, float mn, float mx, float cur, Consumer<Float> c) {
        label(t);
        SeekBar s = new SeekBar(this);
        s.setMax(1000);
        s.setProgress((int) ((cur - mn) / (mx - mn) * 1000));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) {
                if (u) { c.accept(mn + (mx - mn) * p / 1000f); Hub.dirty = true; }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) { Hub.save(MainActivity.this); }
        });
        root.addView(s);
    }

    void start() {
        if (Hub.running) { toast("กำลังสตรีมอยู่แล้ว"); return; }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            toast("เปิด 'แสดงทับแอพอื่น' ให้แอพนี้ แล้วกลับมากดเริ่มใหม่");
            return;
        }
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), 100);
    }

    @Override protected void onActivityResult(int rq, int rc, Intent d) {
        super.onActivityResult(rq, rc, d);
        if (rq != 100) return;
        if (rc == RESULT_OK && d != null) {
            Hub.save(this);
            startForegroundService(new Intent(this, MirrorService.class).putExtra("rc", rc).putExtra("data", d));
        } else toast("ไม่ได้อนุญาตให้จับภาพหน้าจอ");
    }

    @Override protected void onPause() { super.onPause(); Hub.save(this); }
}
