package com.arcinema.app;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.display.DisplayManager;
import android.media.projection.MediaProjectionManager;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity {
    final Handler h = new Handler(Looper.getMainLooper());
    final Renderer rd = new Renderer();
    FrameLayout root;
    GLSurfaceView gl;
    LinearLayout panel;
    TextView status;
    Button lockBtn;
    MirrorService attachedTo;
    int attachedGen = -1;
    ScaleGestureDetector sgd;
    float lx, ly;
    long shown;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Hub.load(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(2);
        gl.setRenderer(rd);
        gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        root.addView(gl, new FrameLayout.LayoutParams(-1, -1));

        status = new TextView(this);
        status.setTextColor(0xFFBBBBBB);
        status.setTextSize(11);
        status.setBackgroundColor(0x66000000);
        status.setPadding(dp(8), dp(4), dp(8), dp(4));
        root.addView(status, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START));
        root.addView(btn("☰", this::togglePanel), new FrameLayout.LayoutParams(dp(52), dp(44), Gravity.TOP | Gravity.END));

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xDD15151C);
        panel.setPadding(dp(6), dp(6), dp(6), dp(6));
        lockBtn = btn("", () -> { Hub.lock = !Hub.lock; updLock(); });
        row(btn("▶ เริ่มสตรีม", this::start), btn("■ หยุด", () -> startService(new Intent(this, MirrorService.class).setAction("stop"))), lockBtn);
        row(btn("📺 ส่งแอพไปจอแว่น (กดถ้าภาพซ้อนกัน)", this::toGlasses));
        row(btn("↖", () -> corner(-1, -1)), btn("↗", () -> corner(1, -1)), btn("↙", () -> corner(-1, 1)), btn("↘", () -> corner(1, 1)),
            btn("เต็มจอ", () -> { if (!Hub.lock) { Hub.tx = 0; Hub.ty = 0; Hub.sc = 1f; } }));
        row(rep("⬅", () -> mv(-.008f, 0)), rep("⬆", () -> mv(0, -.008f)), rep("⬇", () -> mv(0, .008f)), rep("➡", () -> mv(.008f, 0)),
            rep("－", () -> zoom(.98f)), rep("＋", () -> zoom(1.02f)), btn("⟳", () -> { if (!Hub.lock) Hub.rot = (Hub.rot + 1) % 4; }));
        row(btn("ตั้งจุดนี้เป็นกลาง", () -> { Hub.htx = Hub.tx; Hub.hty = Hub.ty; Hub.hsc = Hub.sc; Hub.save(this); toast("บันทึกจุดกลางแล้ว"); }),
            btn("⌂ กลับจุดกลาง", () -> { if (!Hub.lock) { Hub.tx = Hub.htx; Hub.ty = Hub.hty; Hub.sc = Hub.hsc; } }));
        root.addView(panel, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        setContentView(root);
        updLock();

        sgd = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) { zoom(d.getScaleFactor()); return true; }
        });
        root.setOnTouchListener((v, e) -> {
            show();
            sgd.onTouchEvent(e);
            float cw = Math.max(1, root.getWidth()), ch = Math.max(1, root.getHeight());
            if (!Hub.lock && e.getActionMasked() == MotionEvent.ACTION_MOVE && e.getPointerCount() == 1 && !sgd.isInProgress()) {
                Hub.tx += (e.getX() - lx) / cw;
                Hub.ty += (e.getY() - ly) / ch;
            }
            lx = e.getX(); ly = e.getY();
            return true;
        });
        root.setOnGenericMotionListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_SCROLL) { zoom(1f + .08f * e.getAxisValue(MotionEvent.AXIS_VSCROLL)); return true; }
            if (e.getAction() == MotionEvent.ACTION_HOVER_MOVE) show();
            return false;
        });
        tick();
    }

    @Override protected void onResume() { super.onResume(); gl.onResume(); attachedTo = null; }

    @Override protected void onPause() {
        MirrorService sv = Hub.svc;
        if (sv != null && rd.st != null) sv.detach(rd.st);
        attachedTo = null;
        gl.onPause();
        Hub.save(this);
        super.onPause();
    }

    void tick() {
        MirrorService sv = Hub.svc;
        int g = rd.gen;
        android.graphics.SurfaceTexture s = rd.st;
        if (sv != null && s != null && (attachedTo != sv || attachedGen != g)) { attachedTo = sv; attachedGen = g; sv.attach(s); }
        if (sv == null) attachedTo = null;
        int did = -1;
        if (Build.VERSION.SDK_INT >= 30 && getDisplay() != null) did = getDisplay().getDisplayId();
        String warn = (did == 0 && Hub.running) ? "  ⚠ แอพอยู่บนจอมือถือ ภาพจะซ้อนกัน → กด 📺 ส่งแอพไปจอแว่น" : "";
        status.setText((Hub.running ? "● สตรีม " : "○ ยังไม่สตรีม ") + Hub.msg + String.format(Locale.US,
            " | จอ id %d | ภาพ %dx%d | ขนาด %.2f x %.2f y %.2f หมุน %d", did, Hub.srcW, Hub.srcH, Hub.sc, Hub.tx, Hub.ty, Hub.rot * 90) + warn);
        if (did == 0) shown = System.currentTimeMillis();
        if (Hub.running && panel.getVisibility() == View.VISIBLE && System.currentTimeMillis() - shown > 6000) panel.setVisibility(View.GONE);
        h.postDelayed(this::tick, 300);
    }

    void corner(int sx, int sy) {
        if (Hub.lock) return;
        Hub.sc = 0.5f;
        Hub.tx = sx * (1f - rd.fw * Hub.sc) / 2f;
        Hub.ty = sy * (1f - rd.fh * Hub.sc) / 2f;
    }
    void mv(float dx, float dy) { if (Hub.lock) return; Hub.tx += dx; Hub.ty += dy; }
    void zoom(float f) { if (Hub.lock) return; Hub.sc = Math.max(0.15f, Math.min(5f, Hub.sc * f)); }
    void show() { shown = System.currentTimeMillis(); panel.setVisibility(View.VISIBLE); }
    void togglePanel() { if (panel.getVisibility() == View.VISIBLE) panel.setVisibility(View.GONE); else show(); }
    void updLock() { lockBtn.setText(Hub.lock ? "🔒 ล็อกอยู่" : "🔓 ล็อกจอ"); }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    Button btn(String t, Runnable r) {
        Button x = new Button(this);
        x.setText(t); x.setAllCaps(false); x.setTextSize(13); x.setMinWidth(0); x.setMinimumWidth(0);
        x.setPadding(dp(4), 0, dp(4), 0);
        x.setOnClickListener(v -> { shown = System.currentTimeMillis(); r.run(); });
        return x;
    }

    Button rep(String t, Runnable r) {
        Button x = btn(t, () -> {});
        x.setOnClickListener(null);
        x.setOnTouchListener(new View.OnTouchListener() {
            final Runnable loop = new Runnable() { @Override public void run() { shown = System.currentTimeMillis(); r.run(); h.postDelayed(this, 30); } };
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: v.setPressed(true); h.post(loop); return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: v.setPressed(false); h.removeCallbacks(loop); return true;
                }
                return false;
            }
        });
        return x;
    }

    void row(View... vs) {
        LinearLayout l = new LinearLayout(this);
        for (View v : vs) l.addView(v, new LinearLayout.LayoutParams(0, dp(48), 1));
        panel.addView(l);
    }

    void toGlasses() {
        DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        for (Display d : dm.getDisplays()) {
            if (d.getDisplayId() != Display.DEFAULT_DISPLAY && (d.getFlags() & Display.FLAG_PRIVATE) == 0) {
                try {
                    ActivityOptions o = ActivityOptions.makeBasic();
                    o.setLaunchDisplayId(d.getDisplayId());
                    Intent i = new Intent(this, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                    startActivity(i, o.toBundle());
                    finish();
                } catch (Exception e) { Hub.msg = "ส่งไปจอแว่นไม่ได้: " + e; }
                return;
            }
        }
        Hub.msg = "ไม่พบจอที่สอง เปิด DeX/ต่อแว่นก่อน";
    }

    void start() {
        if (Hub.running) { toast("กำลังสตรีมอยู่แล้ว"); return; }
        Hub.msg = "ขอสิทธิ์จับภาพ... เลือก 'ทั้งหน้าจอ'";
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), 100);
    }

    @Override protected void onActivityResult(int rq, int rc, Intent d) {
        super.onActivityResult(rq, rc, d);
        if (rq != 100) return;
        if (rc == RESULT_OK && d != null) {
            Hub.save(this);
            startForegroundService(new Intent(this, MirrorService.class).putExtra("rc", rc).putExtra("data", d));
        } else Hub.msg = "ไม่ได้อนุญาตให้จับภาพหน้าจอ";
    }

    @Override public boolean onKeyDown(int k, KeyEvent e) {
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_LEFT: mv(-.01f, 0); return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT: mv(.01f, 0); return true;
            case KeyEvent.KEYCODE_DPAD_UP: mv(0, -.01f); return true;
            case KeyEvent.KEYCODE_DPAD_DOWN: mv(0, .01f); return true;
            case KeyEvent.KEYCODE_PLUS:
            case KeyEvent.KEYCODE_EQUALS: zoom(1.04f); return true;
            case KeyEvent.KEYCODE_MINUS: zoom(.96f); return true;
            case KeyEvent.KEYCODE_R: if (!Hub.lock) Hub.rot = (Hub.rot + 1) % 4; return true;
            case KeyEvent.KEYCODE_C: if (!Hub.lock) { Hub.tx = Hub.htx; Hub.ty = Hub.hty; Hub.sc = Hub.hsc; } return true;
            case KeyEvent.KEYCODE_L: Hub.lock = !Hub.lock; updLock(); return true;
            case KeyEvent.KEYCODE_H: togglePanel(); return true;
        }
        return super.onKeyDown(k, e);
    }
}
