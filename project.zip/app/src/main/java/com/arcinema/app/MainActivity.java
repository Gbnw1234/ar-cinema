package com.arcinema.app;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.display.DisplayManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    WebView web;
    ValueCallback<Uri[]> pending;
    volatile int curDid = -1;
    final Handler h = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (pending != null) pending.onReceiveValue(null);
                pending = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("video/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(Intent.createChooser(i, "Select video"), 1);
                return true;
            }
        });
        try {
            if (Hub.server == null) { WebServer ws = new WebServer(getAssets()); ws.start(); Hub.server = ws; }
            web.loadUrl("http://127.0.0.1:" + Hub.server.port() + "/index.html");
        } catch (Exception e) {
            web.loadData("server error: " + e, "text/plain", "utf-8");
        }
    }

    void updDid() { if (Build.VERSION.SDK_INT >= 30 && getDisplay() != null) curDid = getDisplay().getDisplayId(); }
    @Override protected void onResume() { super.onResume(); updDid(); }

    void js(String s) { web.evaluateJavascript(s, null); }

    class Bridge {
        @JavascriptInterface public void startMirror() {
            runOnUiThread(() -> {
                if (Hub.running) { js("onMirrorReady()"); return; }
                Hub.msg = "\u0e02\u0e2d\u0e2a\u0e34\u0e17\u0e18\u0e34\u0e4c\u0e08\u0e31\u0e1a\u0e20\u0e32\u0e1e \u0e40\u0e25\u0e37\u0e2d\u0e01 '\u0e17\u0e31\u0e49\u0e07\u0e2b\u0e19\u0e49\u0e32\u0e08\u0e2d'";
                MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                startActivityForResult(m.createScreenCaptureIntent(), 100);
            });
        }
        @JavascriptInterface public void stopMirror() {
            runOnUiThread(() -> startService(new Intent(MainActivity.this, MirrorService.class).setAction("stop")));
        }
        @JavascriptInterface public void toGlasses() { runOnUiThread(MainActivity.this::sendToGlasses); }
        @JavascriptInterface public int displayId() { return curDid; }
        @JavascriptInterface public String msg() { return Hub.msg; }
    }

    void sendToGlasses() {
        DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        for (Display d : dm.getDisplays()) {
            if (d.getDisplayId() != Display.DEFAULT_DISPLAY && (d.getFlags() & Display.FLAG_PRIVATE) == 0) {
                try {
                    ActivityOptions o = ActivityOptions.makeBasic();
                    o.setLaunchDisplayId(d.getDisplayId());
                    Intent i = new Intent(this, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                    startActivity(i, o.toBundle());
                    finish();
                } catch (Exception e) { Hub.msg = "\u0e2a\u0e48\u0e07\u0e44\u0e1b\u0e08\u0e2d\u0e41\u0e27\u0e48\u0e19\u0e44\u0e21\u0e48\u0e44\u0e14\u0e49: " + e; }
                return;
            }
        }
        Hub.msg = "\u0e44\u0e21\u0e48\u0e1e\u0e1a\u0e08\u0e2d\u0e17\u0e35\u0e48\u0e2a\u0e2d\u0e07 \u0e40\u0e1b\u0e34\u0e14 DeX \u0e01\u0e48\u0e2d\u0e19";
    }

    @Override protected void onActivityResult(int rq, int rc, Intent d) {
        super.onActivityResult(rq, rc, d);
        if (rq == 100) {
            if (rc == RESULT_OK && d != null) {
                startForegroundService(new Intent(this, MirrorService.class).putExtra("rc", rc).putExtra("data", d));
                h.postDelayed(() -> js("onMirrorReady()"), 600);
            } else Hub.msg = "\u0e44\u0e21\u0e48\u0e44\u0e14\u0e49\u0e2d\u0e19\u0e38\u0e0d\u0e32\u0e15\u0e43\u0e2b\u0e49\u0e08\u0e31\u0e1a\u0e20\u0e32\u0e1e\u0e2b\u0e19\u0e49\u0e32\u0e08\u0e2d";
            return;
        }
        if (rq != 1 || pending == null) return;
        Uri[] r = null;
        if (rc == RESULT_OK && d != null) {
            if (d.getClipData() != null) {
                int n = d.getClipData().getItemCount();
                r = new Uri[n];
                for (int i = 0; i < n; i++) r[i] = d.getClipData().getItemAt(i).getUri();
            } else if (d.getData() != null) r = new Uri[]{d.getData()};
        }
        pending.onReceiveValue(r);
        pending = null;
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        updDid();
        if (f) getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
