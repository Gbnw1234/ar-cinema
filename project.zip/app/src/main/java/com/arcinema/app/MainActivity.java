package com.arcinema.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    final Handler h = new Handler(Looper.getMainLooper());
    FrameLayout root;
    TextureView tv;
    LinearLayout panel;
    TextView status;
    Button lockBtn;
    SurfaceTexture surf;
    MirrorService attachedTo;
    ScaleGestureDetector sgd;
    float cw, ch, visW, visH, lx, ly;
    long shown;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Hub.load(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        tv = new TextureView(this);
        tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int hh) { surf = s; attachedTo = null; }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int hh) {}
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s) {
                MirrorService sv = Hub.svc;
                if (sv != null) sv.detach();
                surf = null; attachedTo = null;
                return true;
            }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture s) {}
        });
        root.addView(tv, new FrameLayout.LayoutParams(100, 100, Gravity.CENTER));

        status = new TextView(this);
        status.setTextColor(0xFFAAAAAA);
        status.setTextSize(11);
        status.setPadding(dp(8), dp(4), dp(8), dp(4));
        root.addView(status, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START));

        Button menu = btn("☰", () -> togglePanel());
        root.addView(menu, new FrameLayout.LayoutParams(dp(48), dp(40), Gravity.TOP | Gravity.END));

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xCC15151C);
        panel.setPadding(dp(6), dp(6), dp(6), dp(6));
        lockBtn = btn("", () -> { Hub.lock = !Hub.lock; updLock(); });
        row(btn("▶ เริ่มสตรีม", this::start), btn("■ หยุด", () -> startService(new Intent(this, MirrorService.class).setAction("stop"))), lockBtn);
        row(btn("↖", () -> corner(-1, -1)), btn("↗", () -> corner(1, -1)), btn("↙", () -> corner(-1, 1)), btn("↘", () -> corner(1, 1)),
            btn("กลางจอ", () -> { if (!Hub.lock) { Hub.tx = 0; Hub.ty = 0; Hub.sc = 1f; apply(); } }));
        row(rep("⬅", () -> mv(-.01f, 0)), rep("⬆", () -> mv(0, -.01f)), rep("⬇", () -> mv(0, .01f)), rep("➡", () -> mv(.01f, 0)),
            rep("－", () -> zoom(.98f)), rep("＋", () -> zoom(1.02f)), btn("⟳", () -> { if (!Hub.lock) { Hub.rot = (Hub.rot + 1) % 4; apply(); } }));
        row(btn("ตั้งจุดนี้เป็นกลาง", () -> { Hub.htx = Hub.tx; Hub.hty = Hub.ty; Hub.hsc = Hub.sc; Hub.save(this); toast("บันทึกจุดกลางแล้ว"); }),
            btn("⌂ กลับจุดกลาง", () -> { if (!Hub.lock) { Hub.tx = Hub.htx; Hub.ty = Hub.hty; Hub.sc = Hub.hsc; apply(); } }));
        root.addView(panel, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        setContentView(root);
        updLock();

        sgd = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) { zoom(d.getScaleFactor()); return true; }
        });
        root.setOnTouchListener((v, e) -> {
            show();
            sgd.onTouchEvent(e);
            if (Hub.lock) return true;
            if (e.getActionMasked() == MotionEvent.ACTION_MOVE && e.getPointerCount() == 1 && !sgd.isInProgress()) {
                Hub.tx += (e.getX() - lx) / cw; Hub.ty += (e.getY() - ly) / ch; apply();
            }
            lx = e.getX(); ly = e.getY();
            return true;
        });
        root.setOnGenericMotionListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_SCROLL) { zoom(1f + .08f * e.getAxisValue(MotionEvent.AXIS_VSCROLL)); return true; }
            if (e.getAction() == MotionEvent.ACTION_HOVER_MOVE) show();
            return false;
        });
        root.addOnLayoutChangeListener((v, l, t, r, bt, ol, ot, or, ob) -> apply());
        tick();
    }

    void tick() {
        MirrorService sv = Hub.svc;
        if (sv != null && surf != null && attachedTo != sv) { attachedTo = sv; sv.attach(surf); }
        if (sv == null) attachedTo = null;
        apply();
        String disp = "";
        if (Build.VERSION.SDK_INT >= 30 && getDisplay() != null) disp = " | แอพอยู่จอ id " + getDisplay().getDisplayId();
        status.setText((Hub.running ? "● สตรีม " : "○ ยังไม่สตรีม ") + Hub.msg + disp);
        if (Hub.running && panel.getVisibility() == View.VISIBLE && System.currentTimeMillis() - shown > 6000) panel.setVisibility(View.GONE);
        h.postDelayed(this::tick, 300);
    }

    void apply() {
        cw = root.getWidth(); ch = root.getHeight();
        if (cw == 0 || ch == 0) return;
        float a = (float) Hub.srcW / Hub.srcH;
        boolean odd = (Hub.rot & 1) == 1;
        float av = odd ? 1 / a : a;
        if (cw / ch > av) { visH = ch; visW = ch * av; } else { visW = cw; visH = cw / av; }
        int lw = Math.round(odd ? visH : visW), lh = Math.round(odd ? visW : visH);
        FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) tv.getLayoutParams();
        if (p.width != lw || p.height != lh) { p.width = lw; p.height = lh; tv.setLayoutParams(p); }
        tv.setRotation(Hub.rot * 90f);
        tv.setScaleX(Hub.sc); tv.setScaleY(Hub.sc);
        tv.setTranslationX(Hub.tx * cw); tv.setTranslationY(Hub.ty * ch);
    }

    void corner(int sx, int sy) {
        if (Hub.lock) return;
        Hub.sc = 0.5f;
        Hub.tx = sx * (cw - Hub.sc * visW) / 2f / cw;
        Hub.ty = sy * (ch - Hub.sc * visH) / 2f / ch;
        apply();
    }
    void mv(float dx, float dy) { if (Hub.lock) return; Hub.tx += dx; Hub.ty += dy; apply(); }
    void zoom(float f) { if (Hub.lock) return; Hub.sc = Math.max(0.15f, Math.min(5f, Hub.sc * f)); apply(); }
    void show() { shown = System.currentTimeMillis(); panel.setVisibility(View.VISIBLE); }
    void togglePanel() { if (panel.getVisibility() == View.VISIBLE) panel.setVisibility(View.GONE); else show(); }
    void updLock() { lockBtn.setText(Hub.lock ? "🔒 ล็อกอยู่" : "🔓 ล็อกจอ"); }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    Button btn(String t, Runnable r) {
        Button x = new Button(this);
        x.setText(t); x.setAllCaps(false); x.setTextSize(12); x.setMinWidth(0); x.setMinimumWidth(0);
        x.setPadding(dp(4), 0, dp(4), 0);
        x.setOnClickListener(v -> { shown = System.currentTimeMillis(); r.run(); });
        return x;
    }

    Button rep(String t, Runnable r) {
        Button x = btn(t, () -> {});
        x.setOnClickListener(null);
        x.setOnTouchListener(new View.OnTouchListener() {
            final Runnable loop = new Runnable() { @Override public void run() { shown = System.currentTimeMillis(); r.run(); h.postDelayed(this, 40); } };
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: v.setPressed(true); h.post(loop); return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: v.setPressed(false); h.removeCallbacks(loop); return true;
                }
                return false;
            }
        });
        return x;
    }

    void row(View... vs) {
        LinearLayout l = new LinearLayout(this);
        for (View v : vs) l.addView(v, new LinearLayout.LayoutParams(0, dp(44), 1));
        panel.addView(l);
    }

    void start() {
        if (Hub.running) { toast("กำลังสตรีมอยู่แล้ว"); return; }
        Hub.msg = "ขอสิทธิ์จับภาพหน้าจอ... เลือก 'ทั้งหน้าจอ'";
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), 100);
    }

    @Override protected void onActivityResult(int rq, int rc, Intent d) {
        super.onActivityResult(rq, rc, d);
        if (rq != 100) return;
        if (rc == RESULT_OK && d != null) {
            Hub.save(this);
            startForegroundService(new Intent(this, MirrorService.class).putExtra("rc", rc).putExtra("data", d));
        } else Hub.msg = "ไม่ได้อนุญาตให้จับภาพหน้าจอ";
    }

    @Override public boolean onKeyDown(int k, KeyEvent e) {
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_LEFT: mv(-.01f, 0); return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT: mv(.01f, 0); return true;
            case KeyEvent.KEYCODE_DPAD_UP: mv(0, -.01f); return true;
            case KeyEvent.KEYCODE_DPAD_DOWN: mv(0, .01f); return true;
            case KeyEvent.KEYCODE_PLUS:
            case KeyEvent.KEYCODE_EQUALS: zoom(1.04f); return true;
            case KeyEvent.KEYCODE_MINUS: zoom(.96f); return true;
            case KeyEvent.KEYCODE_R: if (!Hub.lock) { Hub.rot = (Hub.rot + 1) % 4; apply(); } return true;
            case KeyEvent.KEYCODE_C: if (!Hub.lock) { Hub.tx = Hub.htx; Hub.ty = Hub.hty; Hub.sc = Hub.hsc; apply(); } return true;
            case KeyEvent.KEYCODE_L: Hub.lock = !Hub.lock; updLock(); return true;
            case KeyEvent.KEYCODE_H: togglePanel(); return true;
        }
        return super.onKeyDown(k, e);
    }

    @Override protected void onPause() { super.onPause(); Hub.save(this); }
}
