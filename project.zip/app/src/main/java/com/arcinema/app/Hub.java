package com.arcinema.app;

import android.content.Context;
import android.content.SharedPreferences;

public class Hub {
    public static volatile float sc = 1f, tx = 0, ty = 0, hsc = 1f, htx = 0, hty = 0;
    public static volatile int rot = 0, srcW = 1080, srcH = 1920;
    public static volatile boolean lock = false, running = false;
    public static volatile String msg = "";
    public static volatile MirrorService svc;

    public static void save(Context c) {
        c.getSharedPreferences("cfg3", 0).edit().putFloat("sc", sc).putFloat("tx", tx).putFloat("ty", ty)
            .putFloat("hsc", hsc).putFloat("htx", htx).putFloat("hty", hty)
            .putInt("rot", rot).putBoolean("lock", lock).apply();
    }

    public static void load(Context c) {
        SharedPreferences p = c.getSharedPreferences("cfg3", 0);
        sc = p.getFloat("sc", sc); tx = p.getFloat("tx", tx); ty = p.getFloat("ty", ty);
        hsc = p.getFloat("hsc", hsc); htx = p.getFloat("htx", htx); hty = p.getFloat("hty", hty);
        rot = p.getInt("rot", rot); lock = p.getBoolean("lock", lock);
    }
}
