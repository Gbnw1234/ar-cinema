package com.arcinema.app;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class Hub {
    public static final ArrayList<Uri> uri = new ArrayList<>();
    public static final ArrayList<String> src = new ArrayList<>();
    public static volatile WebServer server;
    public static ContentResolver cr;
    // การตั้งค่าจอ
    public static float w = 3.2f, d = 4f, k = 0.3f, gap = 0.08f, x = 0, y = 0, b = 1f, hx = 0, hy = 0;
    public static int n = 1;
    public static boolean span = true;
    // เมาส์/เลเซอร์
    public static float px = .5f, py = .5f, sens = 1.5f, padSens = 1.6f;
    public static boolean air = false, invX = false, invY = false;

    public static String json() {
        try {
            JSONObject o = new JSONObject();
            o.put("w", w); o.put("d", d); o.put("k", k); o.put("gap", gap);
            o.put("x", x); o.put("y", y); o.put("b", b); o.put("n", n); o.put("span", span);
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }

    public static String urlsJson() { return new JSONArray(src).toString(); }

    public static void save(Context c) {
        c.getSharedPreferences("cfg8", 0).edit()
            .putFloat("w", w).putFloat("d", d).putFloat("k", k).putFloat("gap", gap)
            .putFloat("x", x).putFloat("y", y).putFloat("b", b).putFloat("hx", hx).putFloat("hy", hy)
            .putInt("n", n).putBoolean("span", span)
            .putFloat("sens", sens).putFloat("padSens", padSens)
            .putBoolean("air", air).putBoolean("invX", invX).putBoolean("invY", invY).apply();
    }

    public static void load(Context c) {
        SharedPreferences p = c.getSharedPreferences("cfg8", 0);
        w = p.getFloat("w", w); d = p.getFloat("d", d); k = p.getFloat("k", k); gap = p.getFloat("gap", gap);
        x = p.getFloat("x", x); y = p.getFloat("y", y); b = p.getFloat("b", b);
        hx = p.getFloat("hx", hx); hy = p.getFloat("hy", hy);
        n = p.getInt("n", n); span = p.getBoolean("span", span);
        sens = p.getFloat("sens", sens); padSens = p.getFloat("padSens", padSens);
        air = p.getBoolean("air", air); invX = p.getBoolean("invX", invX); invY = p.getBoolean("invY", invY);
    }
}
