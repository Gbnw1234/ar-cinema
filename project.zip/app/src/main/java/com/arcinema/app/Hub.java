package com.arcinema.app;

public class Hub {
    public static final Object LOCK = new Object();
    public static volatile byte[] frame;
    public static volatile long seq = 0;
    public static volatile boolean running = false;
    public static volatile String msg = "";
    public static volatile MirrorService svc;
    public static volatile WebServer server;
}
