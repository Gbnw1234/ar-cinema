package com.arcinema.app;

import android.content.Context;
import android.content.SharedPreferences;

public class Hub {
    public static volatile float w = 2.4f, d = 4f, k = 0.3f, gap = 0.05f, x = 0, y = 0, b = 1f, hx = 0, hy = 0;
    public static volatile float headYaw = 0, headPitch = 0; // ช่องเสียบ head tracking ในอนาคต
    public static volatile int n = 1, rot = 0, srcW = 1080, srcH = 1920;
    public static volatile boolean span = false, lock = false, dirty = true, running = false;

    public static void save(Context c) {
        c.getSharedPreferences("cfg", 0).edit()
            .putFloat("w", w).putFloat("d", d).putFloat("k", k).putFloat("gap", gap)
            .putFloat("x", x).putFloat("y", y).putFloat("b", b).putFloat("hx", hx).putFloat("hy", hy)
            .putInt("n", n).putInt("rot", rot).putBoolean("span", span).putBoolean("lock", lock).apply();
    }

    public static void load(Context c) {
        SharedPreferences p = c.getSharedPreferences("cfg", 0);
        w = p.getFloat("w", w); d = p.getFloat("d", d); k = p.getFloat("k", k); gap = p.getFloat("gap", gap);
        x = p.getFloat("x", x); y = p.getFloat("y", y); b = p.getFloat("b", b);
        hx = p.getFloat("hx", hx); hy = p.getFloat("hy", hy);
        n = p.getInt("n", n); rot = p.getInt("rot", rot);
        span = p.getBoolean("span", span); lock = p.getBoolean("lock", lock);
        dirty = true;
    }
}
