package com.arcinema.app;

import android.content.res.AssetManager;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/** เซิร์ฟเวอร์เล็ก ๆ ในเครื่อง: ส่งหน้าเว็บของแอพ และส่งภาพหน้าจอเป็น MJPEG ที่ /s */
public class WebServer extends Thread {
    final ServerSocket ss;
    final AssetManager am;

    public WebServer(AssetManager am) throws IOException {
        this.am = am;
        ss = new ServerSocket(0, 16, InetAddress.getByName("127.0.0.1"));
        setDaemon(true);
    }

    public int port() { return ss.getLocalPort(); }

    @Override public void run() {
        while (true) {
            try {
                final Socket s = ss.accept();
                new Thread(() -> handle(s)).start();
            } catch (IOException e) { break; }
        }
    }

    void handle(Socket s) {
        try {
            s.setTcpNoDelay(true);
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream()));
            String line = r.readLine();
            if (line == null) return;
            String l;
            while ((l = r.readLine()) != null && !l.isEmpty()) { }
            String path = line.split(" ")[1];
            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);
            OutputStream o = s.getOutputStream();
            if (path.equals("/s")) stream(o);
            else serve(o, path.equals("/") ? "index.html" : path.substring(1));
        } catch (Exception e) {
        } finally {
            try { s.close(); } catch (Exception e) { }
        }
    }

    void serve(OutputStream o, String name) throws IOException {
        InputStream in;
        try { in = am.open(name); }
        catch (IOException e) {
            o.write("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".getBytes());
            return;
        }
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        in.close();
        String type = name.endsWith(".html") ? "text/html; charset=utf-8"
            : name.endsWith(".js") ? "application/javascript; charset=utf-8" : "application/octet-stream";
        o.write(("HTTP/1.1 200 OK\r\nContent-Type: " + type + "\r\nContent-Length: " + b.size()
            + "\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n").getBytes());
        b.writeTo(o);
        o.flush();
    }

    void stream(OutputStream o) throws Exception {
        o.write(("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=f\r\n"
            + "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").getBytes());
        long last = -1;
        while (true) {
            byte[] f;
            synchronized (Hub.LOCK) {
                if (Hub.seq == last) Hub.LOCK.wait(3000);
                f = Hub.frame;
                last = Hub.seq;
            }
            if (f == null) continue;
            o.write(("--f\r\nContent-Type: image/jpeg\r\nContent-Length: " + f.length + "\r\n\r\n").getBytes());
            o.write(f);
            o.write("\r\n".getBytes());
            o.flush();
        }
    }
}
