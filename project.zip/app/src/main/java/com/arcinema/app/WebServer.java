package com.arcinema.app;

import android.content.res.AssetManager;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/** เซิร์ฟเวอร์ในเครื่อง: ส่งหน้าเว็บโรงหนัง และส่งไฟล์วิดีโอที่เลือก (รองรับการกรอ/Range) */
public class WebServer extends Thread {
    final ServerSocket ss;
    final AssetManager am;

    public WebServer(AssetManager am) throws IOException {
        this.am = am;
        ss = new ServerSocket(0, 32, InetAddress.getByName("127.0.0.1"));
        setDaemon(true);
    }

    public int port() { return ss.getLocalPort(); }

    @Override public void run() {
        while (true) {
            try {
                final Socket s = ss.accept();
                new Thread(() -> handle(s)).start();
            } catch (IOException e) { break; }
        }
    }

    void handle(Socket s) {
        try {
            s.setTcpNoDelay(true);
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream()));
            String line = r.readLine();
            if (line == null) return;
            String range = null, l;
            while ((l = r.readLine()) != null && !l.isEmpty()) {
                if (l.toLowerCase().startsWith("range:")) range = l.substring(6).trim();
            }
            String path = line.split(" ")[1];
            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);
            OutputStream o = s.getOutputStream();
            if (path.startsWith("/v/")) video(o, Integer.parseInt(path.substring(3)), range);
            else serve(o, path.equals("/") ? "cinema.html" : path.substring(1));
        } catch (Exception e) {
        } finally {
            try { s.close(); } catch (Exception e) { }
        }
    }

    void notFound(OutputStream o) throws IOException {
        o.write("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".getBytes());
    }

    void serve(OutputStream o, String name) throws IOException {
        InputStream in;
        try { in = am.open(name); } catch (IOException e) { notFound(o); return; }
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        in.close();
        String type = name.endsWith(".html") ? "text/html; charset=utf-8"
            : name.endsWith(".js") ? "application/javascript; charset=utf-8" : "application/octet-stream";
        o.write(("HTTP/1.1 200 OK\r\nContent-Type: " + type + "\r\nContent-Length: " + b.size()
            + "\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n").getBytes());
        b.writeTo(o);
        o.flush();
    }

    void video(OutputStream o, int idx, String range) throws IOException {
        Uri u;
        synchronized (Hub.class) { u = idx >= 0 && idx < Hub.uri.size() ? Hub.uri.get(idx) : null; }
        if (u == null) { notFound(o); return; }
        ParcelFileDescriptor pfd = Hub.cr.openFileDescriptor(u, "r");
        long len = pfd.getStatSize();
        String type = Hub.cr.getType(u);
        if (type == null) type = "video/mp4";
        long s = 0, e = len - 1;
        boolean part = false;
        if (range != null && range.startsWith("bytes=")) {
            String[] p = range.substring(6).split("-");
            try {
                if (p.length > 0 && !p[0].isEmpty()) s = Long.parseLong(p[0].trim());
                if (p.length > 1 && !p[1].isEmpty()) e = Long.parseLong(p[1].trim());
            } catch (Exception x) { }
            part = true;
        }
        if (e >= len) e = len - 1;
        if (s > e) {
            o.write("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".getBytes());
            pfd.close();
            return;
        }
        FileInputStream in = new FileInputStream(pfd.getFileDescriptor());
        in.getChannel().position(s);
        String head = (part ? "HTTP/1.1 206 Partial Content\r\nContent-Range: bytes " + s + "-" + e + "/" + len + "\r\n"
            : "HTTP/1.1 200 OK\r\n")
            + "Accept-Ranges: bytes\r\nContent-Type: " + type + "\r\nContent-Length: " + (e - s + 1)
            + "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
        o.write(head.getBytes());
        byte[] buf = new byte[64 * 1024];
        long remain = e - s + 1;
        try {
            while (remain > 0) {
                int n = in.read(buf, 0, (int) Math.min(buf.length, remain));
                if (n < 0) break;
                o.write(buf, 0, n);
                remain -= n;
            }
            o.flush();
        } finally {
            in.close();
            pfd.close();
        }
    }
}
