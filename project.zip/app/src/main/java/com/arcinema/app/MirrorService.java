package com.arcinema.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Display;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

public class MirrorService extends Service {
    MediaProjection mp;
    VirtualDisplay vd;
    ImageReader ir;
    DisplayManager dm;
    HandlerThread ht;
    Handler ih;
    Bitmap bmp;
    final ByteArrayOutputStream bos = new ByteArrayOutputStream();
    long last;
    int fc;
    int cw, chh;
    boolean stopped;
    final Handler h = new Handler(Looper.getMainLooper());
    final DisplayManager.DisplayListener dl = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int i) {}
        @Override public void onDisplayRemoved(int i) {}
        @Override public void onDisplayChanged(int i) { if (i == Display.DEFAULT_DISPLAY) resize(); }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int sid) {
        if (i == null || "stop".equals(i.getAction())) { stopAll(); stopSelf(); return START_NOT_STICKY; }
        try {
            startFg();
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            Intent data = i.getParcelableExtra("data");
            mp = m.getMediaProjection(i.getIntExtra("rc", 0), data);
            mp.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { h.post(() -> { stopAll(); stopSelf(); }); }
            }, h);
            dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
            ht = new HandlerThread("cap");
            ht.start();
            ih = new Handler(ht.getLooper());
            int[] s = size();
            cw = s[0]; chh = s[1];
            ir = newReader(cw, chh);
            vd = mp.createVirtualDisplay("ARMirror", cw, chh, dpi(),
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir.getSurface(), null, null);
            dm.registerDisplayListener(dl, h);
            Hub.svc = this;
            Hub.running = true;
            Hub.msg = "\u0e2a\u0e15\u0e23\u0e35\u0e21\u0e2d\u0e22\u0e39\u0e48 " + cw + "x" + chh;
        } catch (Exception e) {
            Hub.msg = "\u0e40\u0e23\u0e34\u0e48\u0e21\u0e2a\u0e15\u0e23\u0e35\u0e21\u0e44\u0e21\u0e48\u0e44\u0e14\u0e49: " + e;
            stopAll(); stopSelf();
        }
        return START_NOT_STICKY;
    }

    ImageReader newReader(int w, int hh) {
        ImageReader r = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2);
        r.setOnImageAvailableListener(this::onImg, ih);
        return r;
    }

    void onImg(ImageReader r) {
        Image im = null;
        try {
            im = r.acquireLatestImage();
            if (im == null) return;
            long now = SystemClock.uptimeMillis();
            if (now - last < 33) return;
            last = now;
            Image.Plane p = im.getPlanes()[0];
            ByteBuffer buf = p.getBuffer();
            int ps = p.getPixelStride(), rs = p.getRowStride(), w = im.getWidth(), hh = im.getHeight();
            int bw = rs / ps;
            if (bmp == null || bmp.getWidth() != bw || bmp.getHeight() != hh)
                bmp = Bitmap.createBitmap(bw, hh, Bitmap.Config.ARGB_8888);
            buf.rewind();
            bmp.copyPixelsFromBuffer(buf);
            if ((fc++ % 15) == 0) {
                int mx = 0, sy = Math.max(1, hh / 24), sx = Math.max(1, w / 24);
                for (int yy = 0; yy < hh; yy += sy)
                    for (int xx = 0; xx < w; xx += sx) {
                        int c = bmp.getPixel(xx, yy);
                        mx = Math.max(mx, Math.max((c >> 16) & 255, Math.max((c >> 8) & 255, c & 255)));
                    }
                Hub.msg = mx < 8 ? "\u26a0 \u0e20\u0e32\u0e1e\u0e17\u0e35\u0e48\u0e08\u0e31\u0e1a\u0e44\u0e14\u0e49\u0e14\u0e33\u0e2a\u0e19\u0e34\u0e17 (\u0e40\u0e0a\u0e47\u0e04 DeX \u0e42\u0e2b\u0e21\u0e14\u0e41\u0e22\u0e01\u0e08\u0e2d / \u0e41\u0e2d\u0e1e\u0e01\u0e31\u0e19\u0e08\u0e31\u0e1a\u0e20\u0e32\u0e1e)"
                    : "\u0e2a\u0e15\u0e23\u0e35\u0e21\u0e1b\u0e01\u0e15\u0e34 " + w + "x" + hh + " \u0e40\u0e1f\u0e23\u0e21 " + Hub.seq;
            }
            Bitmap src = bw == w ? bmp : Bitmap.createBitmap(bmp, 0, 0, w, hh);
            bos.reset();
            src.compress(Bitmap.CompressFormat.JPEG, 75, bos);
            byte[] f = bos.toByteArray();
            synchronized (Hub.LOCK) { Hub.frame = f; Hub.seq++; Hub.LOCK.notifyAll(); }
        } catch (Exception e) {
            Hub.msg = "\u0e40\u0e1f\u0e23\u0e21\u0e1c\u0e34\u0e14\u0e1e\u0e25\u0e32\u0e14: " + e;
        } finally {
            if (im != null) im.close();
        }
    }

    void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("m", "AR Cinema", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getService(this, 0,
            new Intent(this, MirrorService.class).setAction("stop"), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "m")
            .setContentTitle("AR Cinema").setContentText("\u0e01\u0e33\u0e25\u0e31\u0e07\u0e2a\u0e15\u0e23\u0e35\u0e21\u0e2b\u0e19\u0e49\u0e32\u0e08\u0e2d")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_delete, "\u0e2b\u0e22\u0e38\u0e14", pi).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(1, n);
    }

    int[] size() {
        DisplayMetrics m = new DisplayMetrics();
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m);
        float sc = Math.min(1f, 1920f / Math.max(m.widthPixels, m.heightPixels));
        return new int[]{(int) (m.widthPixels * sc) & ~1, (int) (m.heightPixels * sc) & ~1};
    }

    int dpi() { return getResources().getDisplayMetrics().densityDpi; }

    void resize() {
        try {
            if (vd == null || stopped) return;
            int[] s = size();
            if (s[0] == cw && s[1] == chh) return;
            cw = s[0]; chh = s[1];
            ImageReader old = ir;
            ir = newReader(cw, chh);
            vd.setSurface(ir.getSurface());
            vd.resize(cw, chh, dpi());
            if (old != null) old.close();
            bmp = null;
            Hub.msg = "\u0e2a\u0e15\u0e23\u0e35\u0e21\u0e2d\u0e22\u0e39\u0e48 " + cw + "x" + chh;
        } catch (Exception e) { Hub.msg = "\u0e1b\u0e23\u0e31\u0e1a\u0e02\u0e19\u0e32\u0e14\u0e44\u0e21\u0e48\u0e44\u0e14\u0e49: " + e; }
    }

    void stopAll() {
        if (stopped) return;
        stopped = true;
        Hub.running = false;
        Hub.svc = null;
        try { dm.unregisterDisplayListener(dl); } catch (Exception e) {}
        try { if (vd != null) vd.release(); } catch (Exception e) {}
        try { if (ir != null) ir.close(); } catch (Exception e) {}
        try { if (mp != null) mp.stop(); } catch (Exception e) {}
        try { if (ht != null) ht.quitSafely(); } catch (Exception e) {}
    }

    @Override public void onDestroy() { stopAll(); super.onDestroy(); }
}
