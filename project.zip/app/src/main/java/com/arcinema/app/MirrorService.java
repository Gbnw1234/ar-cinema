package com.arcinema.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.SurfaceTexture;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Surface;

public class MirrorService extends Service {
    MediaProjection mp;
    VirtualDisplay vd;
    DisplayManager dm;
    SurfaceTexture cur;
    boolean stopped;
    final Handler h = new Handler(Looper.getMainLooper());
    final DisplayManager.DisplayListener dl = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int i) {}
        @Override public void onDisplayRemoved(int i) {}
        @Override public void onDisplayChanged(int i) { if (i == Display.DEFAULT_DISPLAY) resize(); }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int sid) {
        if (i == null || "stop".equals(i.getAction())) { stopAll(); stopSelf(); return START_NOT_STICKY; }
        try {
            startFg();
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            Intent data = i.getParcelableExtra("data");
            mp = m.getMediaProjection(i.getIntExtra("rc", 0), data);
            mp.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { h.post(() -> { stopAll(); stopSelf(); }); }
            }, h);
            dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
            dm.registerDisplayListener(dl, h);
            Hub.svc = this;
            Hub.running = true;
            Hub.msg = "ได้สิทธิ์จับภาพแล้ว กำลังต่อภาพเข้าหน้าต่าง...";
        } catch (Exception e) {
            Hub.msg = "เริ่มสตรีมไม่ได้: " + e;
            stopAll(); stopSelf();
        }
        return START_NOT_STICKY;
    }

    void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("m", "AR Mirror", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getService(this, 0,
            new Intent(this, MirrorService.class).setAction("stop"), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "m")
            .setContentTitle("AR Mirror").setContentText("กำลังสตรีมหน้าจอ")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_delete, "หยุด", pi).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(1, n);
    }

    int[] size() {
        DisplayMetrics m = new DisplayMetrics();
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m);
        float sc = Math.min(1f, 1920f / Math.max(m.widthPixels, m.heightPixels));
        return new int[]{(int) (m.widthPixels * sc) & ~1, (int) (m.heightPixels * sc) & ~1};
    }

    int dpi() { return getResources().getDisplayMetrics().densityDpi; }

    public void attach(SurfaceTexture st) {
        try {
            if (mp == null || stopped) return;
            cur = st;
            int[] s = size();
            st.setDefaultBufferSize(s[0], s[1]);
            Hub.srcW = s[0]; Hub.srcH = s[1];
            Surface sf = new Surface(st);
            if (vd != null) { vd.setSurface(sf); vd.resize(s[0], s[1], dpi()); }
            else vd = mp.createVirtualDisplay("ARMirror", s[0], s[1], dpi(),
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, sf, null, null);
            Hub.msg = "ต่อภาพสำเร็จ " + s[0] + "x" + s[1];
        } catch (Exception e) {
            Hub.msg = "ต่อภาพไม่ได้: " + e;
        }
    }

    public void detach(SurfaceTexture st) {
        if (cur != st) return;
        try { if (vd != null) vd.setSurface(null); } catch (Exception e) {}
        cur = null;
    }

    void resize() {
        try {
            if (vd == null || cur == null || stopped) return;
            int[] s = size();
            cur.setDefaultBufferSize(s[0], s[1]);
            vd.resize(s[0], s[1], dpi());
            Hub.srcW = s[0]; Hub.srcH = s[1];
        } catch (Exception e) { Hub.msg = "ปรับขนาดไม่ได้: " + e; }
    }

    void stopAll() {
        if (stopped) return;
        stopped = true;
        Hub.running = false;
        Hub.svc = null;
        try { dm.unregisterDisplayListener(dl); } catch (Exception e) {}
        try { if (vd != null) vd.release(); } catch (Exception e) {}
        try { if (mp != null) mp.stop(); } catch (Exception e) {}
    }

    @Override public void onDestroy() { stopAll(); super.onDestroy(); }
}
