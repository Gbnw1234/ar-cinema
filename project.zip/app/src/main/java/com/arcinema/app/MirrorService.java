package com.arcinema.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Presentation;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Surface;
import android.view.WindowManager;
import android.widget.Toast;

public class MirrorService extends Service {
    MediaProjection mp;
    VirtualDisplay vd;
    Presentation pres;
    Renderer r;
    DisplayManager dm;
    boolean stopped;
    final Handler h = new Handler(Looper.getMainLooper());
    final DisplayManager.DisplayListener dl = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int i) {}
        @Override public void onDisplayRemoved(int i) {}
        @Override public void onDisplayChanged(int i) { if (i == Display.DEFAULT_DISPLAY) resize(); }
    };

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int sid) {
        if (i == null || "stop".equals(i.getAction())) { stopAll(); stopSelf(); return START_NOT_STICKY; }
        startFg();
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent data = i.getParcelableExtra("data");
        mp = m.getMediaProjection(i.getIntExtra("rc", 0), data);
        mp.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { h.post(() -> { stopAll(); stopSelf(); }); }
        }, h);
        dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        Display ext = null;
        for (Display d : dm.getDisplays()) {
            if (d.getDisplayId() != Display.DEFAULT_DISPLAY && (d.getFlags() & Display.FLAG_PRIVATE) == 0) { ext = d; break; }
        }
        if (ext == null) {
            Toast.makeText(this, "ไม่พบจอแว่น ต่อแว่นและเปิดโหมดขยายจอ/DeX ก่อน แล้วลองใหม่", Toast.LENGTH_LONG).show();
            stopAll(); stopSelf(); return START_NOT_STICKY;
        }
        r = new Renderer();
        r.onReady = () -> h.post(this::capture);
        pres = new Presentation(this, ext) {
            @Override protected void onCreate(Bundle b) {
                super.onCreate(b);
                GLSurfaceView g = new GLSurfaceView(getContext());
                g.setEGLContextClientVersion(2);
                g.setRenderer(r);
                setContentView(g);
            }
        };
        try {
            pres.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
            pres.show();
        } catch (Exception e) {
            Toast.makeText(this, "แสดงบนแว่นไม่ได้: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopAll(); stopSelf(); return START_NOT_STICKY;
        }
        dm.registerDisplayListener(dl, h);
        Hub.running = true;
        return START_NOT_STICKY;
    }

    void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("m", "AR Mirror", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getService(this, 0,
            new Intent(this, MirrorService.class).setAction("stop"), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "m")
            .setContentTitle("AR Mirror").setContentText("กำลังสตรีมไปที่แว่น")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_delete, "หยุด", pi).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(1, n);
    }

    int[] size() {
        DisplayMetrics m = new DisplayMetrics();
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m);
        float sc = Math.min(1f, 1920f / Math.max(m.widthPixels, m.heightPixels));
        return new int[]{(int) (m.widthPixels * sc) & ~1, (int) (m.heightPixels * sc) & ~1};
    }

    int dpi() { return getResources().getDisplayMetrics().densityDpi; }

    void capture() {
        if (mp == null || r == null || r.st == null || stopped) return;
        int[] s = size();
        r.st.setDefaultBufferSize(s[0], s[1]);
        Hub.srcW = s[0]; Hub.srcH = s[1]; Hub.dirty = true;
        Surface sf = new Surface(r.st);
        if (vd != null) { vd.setSurface(sf); vd.resize(s[0], s[1], dpi()); }
        else vd = mp.createVirtualDisplay("ARMirror", s[0], s[1], dpi(),
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, sf, null, null);
    }

    void resize() {
        if (vd == null || r == null || r.st == null || stopped) return;
        int[] s = size();
        r.st.setDefaultBufferSize(s[0], s[1]);
        vd.resize(s[0], s[1], dpi());
        Hub.srcW = s[0]; Hub.srcH = s[1]; Hub.dirty = true;
    }

    void stopAll() {
        if (stopped) return;
        stopped = true;
        Hub.running = false;
        try { dm.unregisterDisplayListener(dl); } catch (Exception e) {}
        try { if (vd != null) vd.release(); } catch (Exception e) {}
        try { if (pres != null) pres.dismiss(); } catch (Exception e) {}
        try { if (mp != null) mp.stop(); } catch (Exception e) {}
    }

    @Override public void onDestroy() { stopAll(); super.onDestroy(); }
}
