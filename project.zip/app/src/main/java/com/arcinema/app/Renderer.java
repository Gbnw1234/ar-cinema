package com.arcinema.app;

import android.graphics.SurfaceTexture;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class Renderer implements GLSurfaceView.Renderer {
    public volatile SurfaceTexture st;
    public Runnable onReady;
    volatile boolean frame;
    int prog, tex, aP, aU, uM, uT, uB, per, panels;
    final float[] proj = new float[16], view = new float[16], mvp = new float[16], stm = new float[16];
    FloatBuffer vb;
    static final int SEG = 32;
    static final String VS = "attribute vec4 aP;attribute vec2 aU;uniform mat4 uM;uniform mat4 uT;varying vec2 vUV;"
        + "void main(){gl_Position=uM*aP;vUV=(uT*vec4(aU,0.0,1.0)).xy;}";
    static final String FS = "#extension GL_OES_EGL_image_external : require\n"
        + "precision mediump float;varying vec2 vUV;uniform samplerExternalOES uTex;uniform float uB;"
        + "void main(){gl_FragColor=vec4(texture2D(uTex,vUV).rgb*uB,1.0);}";

    int sh(int t, String s) {
        int i = GLES20.glCreateShader(t);
        GLES20.glShaderSource(i, s);
        GLES20.glCompileShader(i);
        return i;
    }

    @Override public void onSurfaceCreated(GL10 g, EGLConfig c) {
        GLES20.glClearColor(0, 0, 0, 1);
        prog = GLES20.glCreateProgram();
        GLES20.glAttachShader(prog, sh(GLES20.GL_VERTEX_SHADER, VS));
        GLES20.glAttachShader(prog, sh(GLES20.GL_FRAGMENT_SHADER, FS));
        GLES20.glLinkProgram(prog);
        aP = GLES20.glGetAttribLocation(prog, "aP");
        aU = GLES20.glGetAttribLocation(prog, "aU");
        uM = GLES20.glGetUniformLocation(prog, "uM");
        uT = GLES20.glGetUniformLocation(prog, "uT");
        uB = GLES20.glGetUniformLocation(prog, "uB");
        int[] t = new int[1];
        GLES20.glGenTextures(1, t, 0);
        tex = t[0];
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        Matrix.setIdentityM(stm, 0);
        SurfaceTexture s = new SurfaceTexture(tex);
        s.setOnFrameAvailableListener(x -> frame = true);
        st = s;
        Hub.dirty = true;
        if (onReady != null) onReady.run();
    }

    @Override public void onSurfaceChanged(GL10 g, int w, int h) {
        GLES20.glViewport(0, 0, w, h);
        // มุมมองแนวตั้ง ~26 องศา ใกล้เคียงจอ Air 1 (16:9 ทแยง 46 องศา)
        Matrix.perspectiveM(proj, 0, 26f, (float) w / h, 0.1f, 50f);
    }

    void build() {
        int n = Hub.n;
        float wP = Hub.w;
        boolean odd = (Hub.rot & 1) == 1;
        float asp = odd ? (float) Hub.srcH / Hub.srcW : (float) Hub.srcW / Hub.srcH;
        float hP = wP / asp;
        float tot = n * wP + (n - 1) * Hub.gap;
        float k = Math.max(Hub.k, 0.001f);
        float R = Hub.d / k;
        per = (SEG + 1) * 2;
        float[] a = new float[n * per * 5];
        int o = 0;
        for (int i = 0; i < n; i++) {
            float s0 = -tot / 2 + i * (wP + Hub.gap);
            for (int j = 0; j <= SEG; j++) {
                float u = j / (float) SEG;
                float s = s0 + u * wP;
                float ang = s / R;
                float X = (float) (R * Math.sin(ang)) + Hub.x;
                float Z = -Hub.d + (float) (R * (1 - Math.cos(ang)));
                float su = Hub.span ? (s + tot / 2) / tot : u;
                for (int r = 0; r < 2; r++) {
                    float sv = r;
                    float iu, iv;
                    switch (Hub.rot & 3) {
                        case 0: iu = su; iv = sv; break;
                        case 1: iu = 1 - sv; iv = su; break;
                        case 2: iu = 1 - su; iv = 1 - sv; break;
                        default: iu = sv; iv = 1 - su; break;
                    }
                    a[o++] = X; a[o++] = (sv - .5f) * hP + Hub.y; a[o++] = Z; a[o++] = iu; a[o++] = iv;
                }
            }
        }
        vb = ByteBuffer.allocateDirect(a.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        vb.put(a);
        panels = n;
    }

    @Override public void onDrawFrame(GL10 g) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        SurfaceTexture s = st;
        if (s == null) return;
        if (frame) {
            frame = false;
            s.updateTexImage();
            s.getTransformMatrix(stm);
        }
        if (Hub.dirty) { Hub.dirty = false; build(); }
        if (vb == null) return;
        Matrix.setIdentityM(view, 0);
        Matrix.rotateM(view, 0, Hub.headPitch, 1, 0, 0);
        Matrix.rotateM(view, 0, Hub.headYaw, 0, 1, 0);
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0);
        GLES20.glUseProgram(prog);
        GLES20.glUniformMatrix4fv(uM, 1, false, mvp, 0);
        GLES20.glUniformMatrix4fv(uT, 1, false, stm, 0);
        GLES20.glUniform1f(uB, Hub.b);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex);
        vb.position(0);
        GLES20.glVertexAttribPointer(aP, 3, GLES20.GL_FLOAT, false, 20, vb);
        GLES20.glEnableVertexAttribArray(aP);
        vb.position(3);
        GLES20.glVertexAttribPointer(aU, 2, GLES20.GL_FLOAT, false, 20, vb);
        GLES20.glEnableVertexAttribArray(aU);
        for (int i = 0; i < panels; i++) GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, i * per, per);
    }
}
