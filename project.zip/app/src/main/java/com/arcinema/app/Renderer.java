package com.arcinema.app;

import android.graphics.SurfaceTexture;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** วาดภาพมิเรอร์เป็นสี่เหลี่ยมหนึ่งแผ่น คำนวณสัดส่วน/ตำแหน่ง/ขนาด/การหมุนเองทั้งหมด */
public class Renderer implements GLSurfaceView.Renderer {
    public volatile SurfaceTexture st;
    public volatile int gen;
    public volatile float fw = 1f, fh = 1f; // ขนาดภาพตอนพอดีจอ (สัดส่วนของครึ่งจอ)
    volatile boolean frame;
    int prog, tex, aP, aU, uS, uO, uT, vw = 1, vh = 1;
    final float[] stm = new float[16];
    final FloatBuffer vb = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    static final String VS = "attribute vec2 aP;attribute vec2 aU;uniform vec2 uS;uniform vec2 uO;uniform mat4 uT;varying vec2 vUV;"
        + "void main(){gl_Position=vec4(aP*uS+uO,0.0,1.0);vUV=(uT*vec4(aU,0.0,1.0)).xy;}";
    static final String FS = "#extension GL_OES_EGL_image_external : require\n"
        + "precision mediump float;varying vec2 vUV;uniform samplerExternalOES uTex;"
        + "void main(){gl_FragColor=vec4(texture2D(uTex,vUV).rgb,1.0);}";

    int sh(int t, String s) {
        int i = GLES20.glCreateShader(t);
        GLES20.glShaderSource(i, s);
        GLES20.glCompileShader(i);
        return i;
    }

    @Override public void onSurfaceCreated(GL10 g, EGLConfig c) {
        prog = GLES20.glCreateProgram();
        GLES20.glAttachShader(prog, sh(GLES20.GL_VERTEX_SHADER, VS));
        GLES20.glAttachShader(prog, sh(GLES20.GL_FRAGMENT_SHADER, FS));
        GLES20.glLinkProgram(prog);
        aP = GLES20.glGetAttribLocation(prog, "aP");
        aU = GLES20.glGetAttribLocation(prog, "aU");
        uS = GLES20.glGetUniformLocation(prog, "uS");
        uO = GLES20.glGetUniformLocation(prog, "uO");
        uT = GLES20.glGetUniformLocation(prog, "uT");
        int[] t = new int[1];
        GLES20.glGenTextures(1, t, 0);
        tex = t[0];
        int T = GLES11Ext.GL_TEXTURE_EXTERNAL_OES;
        GLES20.glBindTexture(T, tex);
        GLES20.glTexParameteri(T, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(T, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(T, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(T, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        Matrix.setIdentityM(stm, 0);
        SurfaceTexture s = new SurfaceTexture(tex);
        s.setOnFrameAvailableListener(x -> frame = true);
        st = s;
        gen++;
    }

    @Override public void onSurfaceChanged(GL10 g, int w, int h) {
        vw = Math.max(1, w); vh = Math.max(1, h);
        GLES20.glViewport(0, 0, w, h);
    }

    @Override public void onDrawFrame(GL10 g) {
        GLES20.glClearColor(0, 0, 0, 1);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        SurfaceTexture s = st;
        if (s == null) return;
        if (frame) {
            frame = false;
            try { s.updateTexImage(); s.getTransformMatrix(stm); } catch (Exception e) { }
        }
        float viewAsp = (float) vw / vh;
        float a = (float) Hub.srcW / Hub.srcH;
        boolean odd = (Hub.rot & 1) == 1;
        float av = odd ? 1f / a : a;
        float hw, hh;
        if (viewAsp > av) { hh = 1f; hw = av / viewAsp; } else { hw = 1f; hh = viewAsp / av; }
        fw = hw; fh = hh;
        float[][] c = {{0, 0}, {1, 0}, {0, 1}, {1, 1}};
        vb.clear();
        for (float[] p : c) {
            float su = p[0], sv = p[1], iu, iv;
            switch (Hub.rot & 3) {
                case 0: iu = su; iv = sv; break;
                case 1: iu = 1 - sv; iv = su; break;
                case 2: iu = 1 - su; iv = 1 - sv; break;
                default: iu = sv; iv = 1 - su; break;
            }
            vb.put(su * 2 - 1).put(sv * 2 - 1).put(iu).put(iv);
        }
        GLES20.glUseProgram(prog);
        GLES20.glUniform2f(uS, hw * Hub.sc, hh * Hub.sc);
        GLES20.glUniform2f(uO, Hub.tx * 2f, -Hub.ty * 2f);
        GLES20.glUniformMatrix4fv(uT, 1, false, stm, 0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex);
        vb.position(0);
        GLES20.glVertexAttribPointer(aP, 2, GLES20.GL_FLOAT, false, 16, vb);
        GLES20.glEnableVertexAttribArray(aP);
        vb.position(2);
        GLES20.glVertexAttribPointer(aU, 2, GLES20.GL_FLOAT, false, 16, vb);
        GLES20.glEnableVertexAttribArray(aU);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
    }
}
